package com.inxedu.os.constants.enums;

/**
 * 订单状态
 */
public enum OrderState {
	SUCCESS,//已支付
	INIT,//未支付
	CANCEL//已取消
}
