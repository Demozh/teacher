package com.inxedu.os.constants.enums;

/**
 *  课程销售方式
 */
public enum VideoType {
    CC,//cc视频
    FIVESIX,//56视频
    LS,//swf地址时使用
    mp4flv//本地的MP4，flv,mp3
}
